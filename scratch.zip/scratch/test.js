export var thing = {
  blah: 1,
}
